HackerSmacker's LUA/370
Based on actual Lua.

Compiling:
make
